import './App.css';
import Chart from './components/charts';
import React from 'react';

function App() {
  return (
    
    <div className="App">
       <h1>test</h1>
    <Chart /> 
      </div>
  );
}
export default App;